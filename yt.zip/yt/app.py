import os
import json
import innertube
import uuid
import subprocess
from flask import Flask, request, jsonify, send_from_directory, render_template

# This is a simple Flask server to handle video downloads using yt-dlp.

app = Flask(__name__)

# Directory where downloaded videos will be stored.
DOWNLOAD_FOLDER = 'downloads'
if not os.path.exists(DOWNLOAD_FOLDER):
    os.makedirs(DOWNLOAD_FOLDER)

@app.route('/watch')
def watch():
    return render_template('watch.html')

@app.route('/')
def index():
    return render_template('home.html')

@app.route('/list', methods=['POST'])
def listfunc():
    """API endpoint for listing of videos."""
    data = request.get_json()
    client = innertube.InnerTube("WEB")
    data = client.search(data.get('search', ''))
    vidlist = []
    videos = data.get('contents').get('twoColumnSearchResultsRenderer').get('primaryContents').get('sectionListRenderer').get('contents')[0].get('itemSectionRenderer').get('contents')
    for i in videos:
        renderer = i.get('videoRenderer')
        if not renderer == None:
            title = renderer.get('title').get('runs')[0].get('text')
            videoId = renderer.get('videoId', 'no ID found')
            thumbnail = renderer.get('thumbnail').get('thumbnails')[0].get('url')
            vidlist.append({'title': title, 'videoId': videoId, 'thumbnail': thumbnail})
            
    return jsonify(vidlist)

@app.route('/download-video', methods=['POST'])
def download_video():
    """
    Handles the video download request from the client.
    
    This function takes a YouTube URL, uses yt-dlp to download the video,
    and returns a JSON object with the URL of the downloaded video file.
    """
    data = request.get_json()
    url = data.get('url')
    vid = data.get('vid')
    print(vid)

    if not url:
        return jsonify({'status': 'error', 'error': 'No URL provided'}), 400

    try:
        filename_prefix = vid
        output_template = os.path.join(DOWNLOAD_FOLDER, filename_prefix + '.mp4')

        if not os.path.exists(output_template):
            # Use subprocess to run yt-dlp
            # We specify a simple MP4 format with both video and audio.
            # This is the key change to ensure audio is always included.
            command = [
                'yt-dlp',
                '-f', 'best[ext=mp4]', # This format downloads a single file with both video and audio
                '--output', output_template,
                url
            ]
    
            # Run the command and capture the output
            result = subprocess.run(command, capture_output=True, text=True, check=True)
            
            # After the download, we need to find the actual filename.
            # The `--output` template might have been changed by yt-dlp.
            # A simpler way for this example is to list the files in the directory
            # and find the one that starts with our unique prefix.
        downloaded_file = None
        for filename in os.listdir(DOWNLOAD_FOLDER):
            if filename.startswith(filename_prefix):
                downloaded_file = filename
                break
        
        if downloaded_file:
            video_url = f'/downloads/{downloaded_file}'
            return jsonify({'status': 'success', 'video_url': video_url})
        else:
            return jsonify({'status': 'error', 'error': 'Download failed to produce a file.'}), 500

    except subprocess.CalledProcessError as e:
        # Catch errors from yt-dlp itself
        return jsonify({'status': 'error', 'error': f'yt-dlp error: {e.stderr}'}), 500
    except Exception as e:
        # Catch any other unexpected errors
        return jsonify({'status': 'error', 'error': str(e)}), 500

@app.route('/downloads/<path:filename>')
def serve_downloaded_file(filename):
    """
    Serves the downloaded video files from the downloads directory.
    """
    return send_from_directory(DOWNLOAD_FOLDER, filename)

if __name__ == '__main__':
    app.run(debug=True)
